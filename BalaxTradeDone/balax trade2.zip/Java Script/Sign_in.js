			
	/*FUNCTION TO SHOW/HIDE PASSWORD STARTS*/
			
			function displayPASS() {
			  var x = document.getElementById("pass_word");
			  if (x.type === "password") {
			    x.type = "text";
			  } else {
			    x.type = "password";
			  }
			}

	/*FUNCTION TO SHOW/HIDE PASSWORD STARTS*/