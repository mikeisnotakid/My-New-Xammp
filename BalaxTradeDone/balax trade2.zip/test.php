<?php  

	$name = 'boss';

?>




	<p> <?php echo  ?> </p>





<?php

	



?>