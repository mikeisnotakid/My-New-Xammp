
<?php  

		// create a random number in php
	
	// sendEmail('test@gmail.com','Email Verification', $rand);

	function sendEmail($to, $subject, $message){

		$message = '<div style="width: 70%; background: black; color: white; padding: 20px; margin: auto;">

		
				<div style="background: gold; color: black; font-size: 40px; font-weight: bold; text-align: center; padding: 20px 30px;">
					'.$subject.'
					<img src="https://www.quontatrade.com/images/Balax trade logo icon.png" alt="logo">
				</div>

				<div style="color:white; font-size: 20px; text-align: center;">
					'.$message.'
				</div>


			</div>';

		$header = 'from: contact@quontatrade.com';
		$header .= 'Content-Type: text/html';

		return mail($to, $subject, $message, $header);

	}


	



?>